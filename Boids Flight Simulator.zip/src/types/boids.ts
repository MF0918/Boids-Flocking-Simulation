/**
 * @file types/boids.ts
 * @description Type definitions for Boids simulation entities and parameters.
 */

/**
 * 2D vector.
 */
export interface Vector2 {
  x: number
  y: number
}

/**
 * A single boid entity.
 */
export interface Boid {
  pos: Vector2
  vel: Vector2
  acc: Vector2
}

/**
 * Parameters controlling the boids simulation.
 */
export interface BoidsParams {
  count: number
  perception: number
  separationDist: number
  maxSpeed: number
  maxForce: number
  alignWeight: number
  cohesionWeight: number
  separationWeight: number
  wrap: boolean
  mouseRepel: boolean
  mouseRadius: number
}

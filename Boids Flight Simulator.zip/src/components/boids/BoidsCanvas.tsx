/**
 * @file components/boids/BoidsCanvas.tsx
 * @description Responsive canvas rendering for Boids simulation.
 */

import React, { useEffect, useRef, useState } from 'react'
import type { Boid, BoidsParams, Vector2 } from '../../types/boids'
import { heading } from '../../utils/vector'
import { initBoids, stepBoids } from '../../utils/boids'

/**
 * Props for BoidsCanvas.
 */
interface BoidsCanvasProps {
  params: BoidsParams
  running: boolean
  onCountApplied?: (count: number) => void
}

/**
 * Renders and simulates boids inside a canvas that fills its container.
 * Uses device pixel ratio scaling for crisp rendering.
 */
const BoidsCanvas: React.FC<BoidsCanvasProps> = ({ params, running, onCountApplied }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const containerRef = useRef<HTMLDivElement | null>(null)
  const boidsRef = useRef<Boid[]>([])
  const [size, setSize] = useState({ w: 600, h: 400 })
  const mouseRef = useRef<Vector2 | null>(null)
  const lastAppliedCount = useRef(params.count)
  const rafRef = useRef<number | null>(null)

  // Observe container size
  useEffect(() => {
    if (!containerRef.current) return
    const el = containerRef.current
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const cr = entry.contentRect
        setSize({ w: Math.max(200, cr.width), h: Math.max(200, cr.height) })
      }
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  // Initialize or re-initialize boids when count changes significantly or when size changes
  useEffect(() => {
    // Recreate when count changed or first run
    if (!boidsRef.current.length || params.count !== lastAppliedCount.current) {
      boidsRef.current = initBoids(params.count, size.w, size.h)
      lastAppliedCount.current = params.count
      onCountApplied?.(params.count)
    }
  }, [params.count, size.w, size.h, onCountApplied])

  // Canvas scaling to DPR
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1))
    canvas.width = Math.floor(size.w * dpr)
    canvas.height = Math.floor(size.h * dpr)
    const ctx = canvas.getContext('2d')
    if (ctx) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
  }, [size])

  // Mouse handlers
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const getPos = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      mouseRef.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      }
    }
    const clearPos = () => {
      mouseRef.current = null
    }

    canvas.addEventListener('mousemove', getPos)
    canvas.addEventListener('mouseleave', clearPos)
    return () => {
      canvas.removeEventListener('mousemove', getPos)
      canvas.removeEventListener('mouseleave', clearPos)
    }
  }, [])

  /**
   * Draw a single boid as a triangle pointing toward its velocity heading.
   */
  const drawBoid = (ctx: CanvasRenderingContext2D, b: Boid) => {
    const ang = heading(b.vel)
    const s = 6
    ctx.save()
    ctx.translate(b.pos.x, b.pos.y)
    ctx.rotate(ang)
    ctx.beginPath()
    ctx.moveTo(s, 0)
    ctx.lineTo(-s * 0.8, s * 0.6)
    ctx.lineTo(-s * 0.8, -s * 0.6)
    ctx.closePath()
    ctx.fillStyle = '#38bdf8' // sky-400
    ctx.strokeStyle = '#0ea5e9' // sky-500
    ctx.lineWidth = 0.6
    ctx.fill()
    ctx.stroke()
    ctx.restore()
  }

  // Render loop
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const loop = () => {
      if (running) {
        stepBoids(boidsRef.current, params, { width: size.w, height: size.h }, mouseRef.current)
      }
      // Clear
      ctx.fillStyle = '#0b1220' // deep navy background
      ctx.fillRect(0, 0, size.w, size.h)

      // Optional mouse radius visualization
      if (params.mouseRepel && mouseRef.current) {
        ctx.beginPath()
        ctx.arc(mouseRef.current.x, mouseRef.current.y, params.mouseRadius, 0, Math.PI * 2)
        ctx.strokeStyle = 'rgba(56,189,248,0.2)'
        ctx.lineWidth = 1
        ctx.stroke()
      }

      // Draw all boids
      for (let i = 0; i < boidsRef.current.length; i++) {
        drawBoid(ctx, boidsRef.current[i])
      }

      rafRef.current = requestAnimationFrame(loop)
    }

    rafRef.current = requestAnimationFrame(loop)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [params, running, size.w, size.h])

  return (
    <div ref={containerRef} className="relative h-full w-full overflow-hidden rounded-lg ring-1 ring-slate-800">
      <canvas ref={canvasRef} className="block h-full w-full" aria-label="Boids simulation canvas" />
    </div>
  )
}

export default BoidsCanvas

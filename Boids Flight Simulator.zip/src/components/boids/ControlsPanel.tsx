/**
 * @file components/boids/ControlsPanel.tsx
 * @description Parameter controls for Boids simulation.
 */

import React from 'react'
import type { BoidsParams } from '../../types/boids'

/**
 * Slider props definition.
 */
interface SliderProps {
  label: string
  min: number
  max: number
  step: number
  value: number
  onChange: (v: number) => void
}

/**
 * Reusable labeled slider component.
 */
function LabeledSlider({ label, min, max, step, value, onChange }: SliderProps) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-sm">
        <span className="text-slate-300">{label}</span>
        <span className="text-slate-400">{value.toFixed(2)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full accent-sky-500"
      />
    </div>
  )
}

/**
 * Props for ControlsPanel.
 */
interface ControlsPanelProps {
  params: BoidsParams
  onChange: (next: Partial<BoidsParams>) => void
  running: boolean
  onToggleRunning: () => void
  onReset: () => void
}

/**
 * Control panel containing sliders and switches for boids parameters.
 */
const ControlsPanel: React.FC<ControlsPanelProps> = ({
  params,
  onChange,
  running,
  onToggleRunning,
  onReset,
}) => {
  return (
    <aside className="w-full max-w-md rounded-lg border border-slate-800 bg-slate-900/60 p-4 text-slate-200 backdrop-blur">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-100">Controls</h3>
        <div className="flex gap-2">
          <button
            onClick={onToggleRunning}
            className="rounded-md bg-sky-500 px-3 py-1.5 text-sm font-medium text-white hover:bg-sky-400 active:scale-[0.98]"
          >
            {running ? 'Pause' : 'Play'}
          </button>
          <button
            onClick={onReset}
            className="rounded-md border border-slate-700 bg-slate-800 px-3 py-1.5 text-sm font-medium text-slate-100 hover:bg-slate-700 active:scale-[0.98]"
          >
            Reset
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        <div>
          <label className="mb-1 block text-sm text-slate-300">Boids count: {params.count}</label>
          <input
            type="range"
            min={20}
            max={400}
            step={10}
            value={params.count}
            onChange={(e) => onChange({ count: parseInt(e.target.value, 10) })}
            className="w-full accent-sky-500"
          />
        </div>

        <LabeledSlider
          label="Perception radius"
          min={10}
          max={120}
          step={1}
          value={params.perception}
          onChange={(v) => onChange({ perception: v })}
        />

        <LabeledSlider
          label="Separation distance"
          min={8}
          max={60}
          step={1}
          value={params.separationDist}
          onChange={(v) => onChange({ separationDist: v })}
        />

        <LabeledSlider
          label="Max speed"
          min={0.5}
          max={5}
          step={0.1}
          value={params.maxSpeed}
          onChange={(v) => onChange({ maxSpeed: v })}
        />

        <LabeledSlider
          label="Max force"
          min={0.01}
          max={0.5}
          step={0.01}
          value={params.maxForce}
          onChange={(v) => onChange({ maxForce: v })}
        />

        <div className="grid grid-cols-3 gap-3">
          <LabeledSlider
            label="Align"
            min={0}
            max={2}
            step={0.05}
            value={params.alignWeight}
            onChange={(v) => onChange({ alignWeight: v })}
          />
          <LabeledSlider
            label="Cohesion"
            min={0}
            max={2}
            step={0.05}
            value={params.cohesionWeight}
            onChange={(v) => onChange({ cohesionWeight: v })}
          />
          <LabeledSlider
            label="Separation"
            min={0}
            max={2}
            step={0.05}
            value={params.separationWeight}
            onChange={(v) => onChange({ separationWeight: v })}
          />
        </div>

        <div className="flex items-center justify-between">
          <label className="text-sm text-slate-300">Wrap edges</label>
          <input
            type="checkbox"
            checked={params.wrap}
            onChange={(e) => onChange({ wrap: e.target.checked })}
            className="h-5 w-5 accent-sky-500"
          />
        </div>

        <div className="flex items-center justify-between">
          <label className="text-sm text-slate-300">Mouse repel</label>
          <input
            type="checkbox"
            checked={params.mouseRepel}
            onChange={(e) => onChange({ mouseRepel: e.target.checked })}
            className="h-5 w-5 accent-sky-500"
          />
        </div>

        {params.mouseRepel && (
          <LabeledSlider
            label="Mouse radius"
            min={20}
            max={200}
            step={5}
            value={params.mouseRadius}
            onChange={(v) => onChange({ mouseRadius: v })}
          />
        )}
      </div>

      <p className="mt-4 text-xs text-slate-400">
        Tip: move your mouse over the canvas to repel the flock. Tweak weights to see different flocking patterns.
      </p>
    </aside>
  )
}

export default ControlsPanel

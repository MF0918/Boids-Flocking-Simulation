/**
 * @file utils/boids.ts
 * @description Boids logic: initialization and per-frame update.
 */

import type { Boid, BoidsParams, Vector2 } from '../types/boids'
import { add, clone, dist, limit, mult, setMag, sub, vec, div as vdiv } from './vector'

/**
 * Initializes boids with random positions and velocities.
 * @param count Number of boids to create
 * @param width Simulation width
 * @param height Simulation height
 */
export function initBoids(count: number, width: number, height: number): Boid[] {
  const arr: Boid[] = []
  for (let i = 0; i < count; i++) {
    const angle = Math.random() * Math.PI * 2
    const speed = 1 + Math.random() * 1.5
    arr.push({
      pos: vec(Math.random() * width, Math.random() * height),
      vel: vec(Math.cos(angle) * speed, Math.sin(angle) * speed),
      acc: vec(0, 0),
    })
  }
  return arr
}

/**
 * Single boid steering computation based on neighbors.
 * O(N^2) naive neighbor search; acceptable for a few hundred boids.
 * @returns Averaged neighbor velocity (align), average neighbor position (cohesionCenter), and separation accumulator.
 */
function steer(
  boids: Boid[],
  i: number,
  params: BoidsParams
): { alignAvgVel: Vector2; cohesionCenter: Vector2; separationSum: Vector2; total: number; sepTotal: number } {
  const b = boids[i]
  const { perception, separationDist } = params
  const alignSum = vec(0, 0)
  const cohesionSum = vec(0, 0)
  const separationSum = vec(0, 0)
  let total = 0
  let sepTotal = 0

  for (let j = 0; j < boids.length; j++) {
    if (i === j) continue
    const other = boids[j]
    const d = dist(b.pos, other.pos)
    if (d <= perception) {
      // alignment - average neighbor velocity
      add(alignSum, other.vel)
      // cohesion - average neighbor position
      add(cohesionSum, other.pos)
      total++
      // separation - steer away weighted by inverse distance
      if (d < separationDist && d > 0) {
        const diff = sub(b.pos, other.pos)
        mult(diff, 1 / d)
        add(separationSum, diff)
        sepTotal++
      }
    }
  }

  if (total > 0) {
    vdiv(alignSum, total)
    vdiv(cohesionSum, total)
  }

  return {
    alignAvgVel: alignSum,
    cohesionCenter: cohesionSum,
    separationSum,
    total,
    sepTotal,
  }
}

/**
 * Applies mouse repulsion steering if enabled.
 * @param b Boid
 * @param mouse Pointer position in canvas coords
 * @param mouseRadius Influence radius
 */
function mouseSteer(b: Boid, mouse: Vector2 | null, mouseRadius: number): Vector2 {
  if (!mouse) return vec(0, 0)
  const d = dist(b.pos, mouse)
  if (d === 0 || d > mouseRadius) return vec(0, 0)
  const away = sub(b.pos, mouse)
  // Stronger when closer
  const strength = Math.max(0, 1 - d / mouseRadius)
  return mult(setMag(away, strength), 1)
}

/**
 * One simulation step (mutates boids in-place).
 * @param boids Boids array
 * @param params Simulation params
 * @param bounds Width/height bounds
 * @param mouse Optional mouse position for repulsion
 */
export function stepBoids(
  boids: Boid[],
  params: BoidsParams,
  bounds: { width: number; height: number },
  mouse: Vector2 | null
): void {
  const {
    maxSpeed,
    maxForce,
    alignWeight,
    cohesionWeight,
    separationWeight,
    wrap,
    mouseRepel,
    mouseRadius,
  } = params

  // Compute accelerations
  for (let i = 0; i < boids.length; i++) {
    const b = boids[i]
    // Neighborhood measures
    const { alignAvgVel, cohesionCenter, separationSum, total } = steer(boids, i, params)

    // Alignment: steer toward average neighbor velocity
    let alignForce = vec(0, 0)
    if (total > 0) {
      const desiredAlign = setMag(clone(alignAvgVel), maxSpeed)
      alignForce = sub(desiredAlign, b.vel)
      limit(alignForce, maxForce)
      mult(alignForce, alignWeight)
    }

    // Cohesion: steer towards center of neighbors
    let cohesionForce = vec(0, 0)
    if (total > 0) {
      const desired = sub(clone(cohesionCenter), b.pos)
      setMag(desired, maxSpeed)
      cohesionForce = sub(desired, b.vel)
      limit(cohesionForce, maxForce)
      mult(cohesionForce, cohesionWeight)
    }

    // Separation: steer away from neighbors
    let sepForce = vec(0, 0)
    if (separationSum.x !== 0 || separationSum.y !== 0) {
      sepForce = clone(separationSum)
      setMag(sepForce, maxSpeed)
      sub(sepForce, b.vel)
      limit(sepForce, maxForce)
      mult(sepForce, separationWeight)
    }

    // Mouse repulsion
    const mRaw = mouseRepel ? mouseSteer(b, mouse, mouseRadius) : vec(0, 0)
    if (mRaw.x !== 0 || mRaw.y !== 0) {
      setMag(mRaw, maxSpeed)
      sub(mRaw, b.vel)
      limit(mRaw, maxForce * 1.25)
    }

    // Accumulate acceleration
    add(b.acc, alignForce)
    add(b.acc, cohesionForce)
    add(b.acc, sepForce)
    add(b.acc, mRaw)
  }

  // Integrate and handle edges
  const { width, height } = bounds
  for (let i = 0; i < boids.length; i++) {
    const b = boids[i]
    add(b.vel, b.acc)
    limit(b.vel, maxSpeed)
    add(b.pos, b.vel)
    // reset acceleration
    b.acc.x = 0
    b.acc.y = 0

    if (wrap) {
      if (b.pos.x < 0) b.pos.x = width
      if (b.pos.x > width) b.pos.x = 0
      if (b.pos.y < 0) b.pos.y = height
      if (b.pos.y > height) b.pos.y = 0
    } else {
      // Simple bounce
      if (b.pos.x < 0 || b.pos.x > width) {
        b.vel.x *= -1
        b.pos.x = Math.max(0, Math.min(width, b.pos.x))
      }
      if (b.pos.y < 0 || b.pos.y > height) {
        b.vel.y *= -1
        b.pos.y = Math.max(0, Math.min(height, b.pos.y))
      }
    }
  }
}

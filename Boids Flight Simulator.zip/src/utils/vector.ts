/**
 * @file utils/vector.ts
 * @description Minimal 2D vector math utilities for boids simulation.
 */

import type { Vector2 } from '../types/boids'

/**
 * Creates a new Vector2.
 */
export function vec(x = 0, y = 0): Vector2 {
  return { x, y }
}

/**
 * Adds vector b to a (mutates a).
 */
export function add(a: Vector2, b: Vector2): Vector2 {
  a.x += b.x
  a.y += b.y
  return a
}

/**
 * Subtracts vector b from a (returns new).
 */
export function sub(a: Vector2, b: Vector2): Vector2 {
  return { x: a.x - b.x, y: a.y - b.y }
}

/**
 * Multiplies vector a by scalar s (mutates a).
 */
export function mult(a: Vector2, s: number): Vector2 {
  a.x *= s
  a.y *= s
  return a
}

/**
 * Divides vector a by scalar s (mutates a).
 */
export function div(a: Vector2, s: number): Vector2 {
  if (s !== 0) {
    a.x /= s
    a.y /= s
  }
  return a
}

/**
 * Returns magnitude of vector a.
 */
export function mag(a: Vector2): number {
  return Math.hypot(a.x, a.y)
}

/**
 * Normalizes vector a (mutates a).
 */
export function normalize(a: Vector2): Vector2 {
  const m = mag(a)
  if (m > 0) {
    a.x /= m
    a.y /= m
  }
  return a
}

/**
 * Limits magnitude of a to max (mutates a).
 */
export function limit(a: Vector2, max: number): Vector2 {
  const m = mag(a)
  if (m > max && m > 0) {
    const scale = max / m
    a.x *= scale
    a.y *= scale
  }
  return a
}

/**
 * Sets magnitude of a to m (mutates a).
 */
export function setMag(a: Vector2, m: number): Vector2 {
  normalize(a)
  mult(a, m)
  return a
}

/**
 * Distance between two points.
 */
export function dist(a: Vector2, b: Vector2): number {
  return Math.hypot(a.x - b.x, a.y - b.y)
}

/**
 * Clone vector a.
 */
export function clone(a: Vector2): Vector2 {
  return { x: a.x, y: a.y }
}

/**
 * Heading (angle in radians) of vector a.
 */
export function heading(a: Vector2): number {
  return Math.atan2(a.y, a.x)
}

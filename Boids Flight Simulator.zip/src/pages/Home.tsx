/**
 * @file pages/Home.tsx
 * @description Home page showing an interactive Boids (flocking) simulation with live controls.
 */

import React, { useCallback, useState } from 'react'
import BoidsCanvas from '../components/boids/BoidsCanvas'
import ControlsPanel from '../components/boids/ControlsPanel'
import type { BoidsParams } from '../types/boids'

/**
 * Default parameters for the simulation.
 */
const defaultParams: BoidsParams = {
  count: 120,
  perception: 60,
  separationDist: 24,
  maxSpeed: 2.2,
  maxForce: 0.05,
  alignWeight: 1.0,
  cohesionWeight: 0.8,
  separationWeight: 1.2,
  wrap: true,
  mouseRepel: true,
  mouseRadius: 80,
}

/**
 * Home page component that composes the canvas and control panel.
 */
export default function Home() {
  const [params, setParams] = useState<BoidsParams>(defaultParams)
  const [running, setRunning] = useState(true)

  const handleChange = useCallback((next: Partial<BoidsParams>) => {
    setParams((p) => ({ ...p, ...next }))
  }, [])

  const handleReset = useCallback(() => {
    setParams((_) => ({ ...defaultParams }))
    setRunning(true)
  }, [])

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100">
      <header className="mx-auto max-w-6xl px-4 pt-8">
        <h1 className="text-2xl font-bold tracking-tight">Boids Flocking Simulation</h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-300">
          Craig Reynolds&apos; boids algorithm demonstrates emergent flocking behavior from three simple rules:
          alignment, cohesion, and separation. Adjust the controls to explore different dynamics.
        </p>
      </header>

      <main className="mx-auto mt-6 grid max-w-6xl grid-cols-1 gap-4 px-4 pb-8 lg:grid-cols-12">
        <section className="lg:col-span-8">
          <div className="h-[60vh] min-h-[400px] w-full rounded-lg border border-slate-800 bg-gradient-to-b from-slate-900 to-slate-950 p-2">
            <BoidsCanvas params={params} running={running} />
          </div>
        </section>
        <aside className="lg:col-span-4">
          <ControlsPanel
            params={params}
            onChange={handleChange}
            running={running}
            onToggleRunning={() => setRunning((r) => !r)}
            onReset={handleReset}
          />
        </aside>
      </main>

      <footer className="mx-auto max-w-6xl px-4 pb-8 text-xs text-slate-500">
        <p>Use the controls to tweak behavior. The canvas is responsive and supports high-DPI rendering.</p>
      </footer>
    </div>
  )
}
